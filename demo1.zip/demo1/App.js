import React, { Component } from 'react';
class App extends Component{
   constructor()
   {
      super();
      this.name="Mani sundar";

   }
   render(){
      return(
         <div>
            <h1>Hello World</h1>
            <p>Welcome to Node {this.name}</p>

         </div>
      );
   }
}
export default App;